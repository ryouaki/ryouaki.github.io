# ryouaki.github.io

我的个人网络简历,兼容手机端[地址](https://ryouaki.github.io)
其实没什么必要用redux，拿来练着玩吧。

# problem

我为啥要把css的类名写那么长。。。。。。。。t_t

# 记录一些技术文章收藏(有空做成交互网页)

## 微服务架构
- [微服务实战(一):(微服务架构的优势与不足)](http://blog.longjiazuo.com/archives/1929)
- [微服务实战(二):(使用API Gateway)](http://blog.longjiazuo.com/archives/3027)
- [微服务实战(三):(深入微服务架构的进程间通信)](http://blog.longjiazuo.com/archives/3052)
- [微服务实战(四):(服务发现的可行方案以及实践案例)](http://blog.longjiazuo.com/archives/3067)
- [微服务实战(五):(微服务的事件驱动数据管理)](http://blog.longjiazuo.com/archives/3080)
- [微服务实战(六):(选择微服务部署策略)](http://blog.longjiazuo.com/archives/3095)
- [微服务实战(七):(从单体式架构迁移到微服务架构)](http://blog.longjiazuo.com/archives/3105)

- [微服务架构下的安全认证与权鉴](https://segmentfault.com/p/1210000009854971/read)
- [微服务那点事](https://segmentfault.com/p/1210000009090743/read)
- [微服务架构下的事务一致性保证](https://m.aliyun.com/yunqi/articles/66109)