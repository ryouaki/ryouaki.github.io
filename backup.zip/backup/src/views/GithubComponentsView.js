import { connect } from 'react-redux';
import GithubComponentsContainer from './templates/github/GithubComponentsContainer';

export default connect( 
    (store) => {
        return {
            
        }
    }, 
    {
        
    }
)(GithubComponentsContainer);