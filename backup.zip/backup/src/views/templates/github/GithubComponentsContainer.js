import React from 'react';

class GithubComponentsContainer extends React.Component {
    render() {
        return (
            <div>还没开发呢 ^_^</div>
        )
    }
}

export default GithubComponentsContainer;