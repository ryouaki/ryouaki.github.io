import GithubIcon from './GithubIcon';
import GroupIcon from './GroupIcon';
import PersonIcon from './PersonIcon';
import AddressIcon from './AddressIcon';
import EmailIcon from './EmailIcon';
import MobileIcon from './MobileIcon';
import WeChatIcon from './WeChatIcon';
import QQIcon from './QQIcon';

export {
    GithubIcon,
    GroupIcon,
    PersonIcon,
    AddressIcon,
    EmailIcon,
    MobileIcon,
    WeChatIcon,
    QQIcon
}