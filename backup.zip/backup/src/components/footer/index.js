import FooterBar from './FooterBar';

export { 
    FooterBar
};
